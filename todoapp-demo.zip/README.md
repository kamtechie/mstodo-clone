## Instructions to run

With Node.js installed run `npm install` in the directory this code is extracted to, then run 'npm start'. The app will load at http://localhost:3000